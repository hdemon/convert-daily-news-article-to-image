const scrape = require('./scrape.js')

scrape.handler()
